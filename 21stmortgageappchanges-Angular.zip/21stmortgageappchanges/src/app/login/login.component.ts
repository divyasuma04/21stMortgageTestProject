import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router, ActivatedRoute} from '@angular/router'
import { LoginserviceService } from '../_services/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 usrname ="";
 password ="";
  isLoggedIn = false;
  isLoginFailed=false;
  isSuccessful=false;
  errorMessage ='';
  constructor(
    private loginService: LoginserviceService) {
   }

  ngOnInit(){
  }
OnSubmit() : void
{

 this.loginService.login(this.usrname,this.password).subscribe(
   data => {
     console.log(data);
     console.log("Welcome");
     this.isSuccessful = true;
     this.isLoggedIn=true;

   },
   err => {
     this.errorMessage = err.error.message;
     this.isLoginFailed = true;
   }
 );
  }
}
