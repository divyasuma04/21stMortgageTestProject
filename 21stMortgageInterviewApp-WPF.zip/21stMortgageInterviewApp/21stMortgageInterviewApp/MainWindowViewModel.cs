﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Text.RegularExpressions;

namespace testapp
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        #region Private variables
        private ICommand largestnum;
        private ICommand sumodd;
        private ICommand sumeven;
        private string input;
        private string result;
        private Brush rescolor;
        #endregion

        #region Properties
        public ICommand LargestNum
        {
            get
            {
                return largestnum;
            }
            set
            {
                largestnum = value;

            }
        }
        public ICommand SumOdd
        {
            get
            {
                return sumodd;
            }
            set
            {
                sumodd = value;

            }
        }
        public ICommand SumEven
        {
            get
            {
                return sumeven;
            }
            set
            {
                sumeven = value;

            }
        }
        public Brush ResColor
        {
            get
            {
                return rescolor;
            }
            set
            {
                rescolor = value;
                this.OnPropertyChanged("ResColor");

            }
        }
        public string Input
        {
            get
            {
                return input;
            }
            set
            {
                input = value;
                this.OnPropertyChanged("Input");
            }
        }

        public string Result
        {
            get
            {
                return result;
            }
            set
            {
                result = value;
                this.OnPropertyChanged("Result");
            }
        }
        #endregion

        public MainWindowViewModel()
        {
            MainWindowModel md = new MainWindowModel();
            md.input = this.Input;
            md.result = this.Result;
            LargestNum = new RelayCommand(new Action<object>(FindLargestNum));
            SumOdd = new RelayCommand(new Action<object>(FindSumOdd));
            SumEven = new RelayCommand(new Action<object>(FindSumEven));
        }
        #region Private Methods
        // Find Largest number by traversing through numbers
        private void FindLargestNum(object obj)
        {

            var num = Input.Split(',');
            int[] intnum = new int[num.Length];
            int cur = 0;
            bool invalid = false;
            for (int i = 0; i < num.Length; i++)
            {
                if(int.TryParse(num[i], out cur))
                {
                    intnum[i] = cur;
                }
                else
                {
                    invalid = true;
                    break;
                }
            }
            if(!invalid)
            {
                var outpt = intnum.Max();
                ResColorFix(outpt);
                this.Result = outpt.ToString();
            }
            else
            {
                MessageBox.Show("Please enter valid User Input. Only Comma separated numbers are allowed.");
            }

        }
        private void ResColorFix(int res)
        {
            if (res > 0)
            {
                this.ResColor = Brushes.Green;
            }
            else
            {
                this.ResColor = Brushes.Red;
            }
        }
        // Find Sum for odd numbers by traversing through numbers
        private void FindSumOdd(object obj)
        {

            var num = Input.Split(',');
            int oddsum = 0;
            int cur = 0;
            bool invalid = false;
            foreach (var str in num)
            {
                if (int.TryParse(str,out cur))
                {
                    if (cur % 2 != 0)
                    {
                        oddsum = oddsum + cur;
                    }
                }
                else
                {
                    invalid = true;
                    break;
                }

            }
            if(!invalid)
            {
                var outpt = oddsum;
                ResColorFix(outpt);
                this.Result = outpt.ToString();
            }
            else
            {
                MessageBox.Show("Please enter valid User Input. Only Comma separated Numbers are allowed.");
            }
        }
        // Find Sum for even numbers by traversing through numbers
        private void FindSumEven(object obj)
        {

            var num = Input.Split(',');
            int evensum = 0;
            int cur = 0;
            bool invalid = false;
            foreach (var str in num)
            {
                if (int.TryParse(str, out cur))
                {
                    if (cur % 2 == 0)
                    {
                        evensum = evensum + cur;
                    }
                }
                else
                {
                    invalid = true;
                    break;
                }
            }
            if(!invalid)
            {
                var outpt = evensum;
                ResColorFix(outpt);
                this.Result = outpt.ToString();
            }
            else
            {
                MessageBox.Show("Please enter valid User Input. Only Comma separated Numbers are allowed.");
            }

        }
        #endregion

        #region INotifyPropertyChanged Methods
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}

