﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testapp
{
    public class MainWindowModel
    {
        public string input { get; set; }
        public string result { get; set; }
    }
}
